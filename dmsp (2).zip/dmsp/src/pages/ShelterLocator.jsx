import React, { useState, useEffect } from 'react';
import './ShelterLocator.css';

const ShelterLocator = () => {
  const [shelters, setShelters] = useState([
    { id: 1, name: "Community Center", address: "123 Main St", distance: "0.5 km", capacity: "120 people", type: "general", contact: "555-0101" },
    { id: 2, name: "High School Gym", address: "456 Oak Ave", distance: "1.2 km", capacity: "300 people", type: "flood", contact: "555-0202" },
    { id: 3, name: "Red Cross Shelter", address: "789 Pine Rd", distance: "2.0 km", capacity: "200 people", type: "earthquake", contact: "555-0303" }
  ]);

  const [showMap, setShowMap] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [disasterTypeFilter, setDisasterTypeFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Show info modal when component first loads
  useEffect(() => {
    setShowInfoModal(true);
  }, []);

  const filteredShelters = shelters.filter(shelter => {
    const matchesType = disasterTypeFilter === 'all' || shelter.type === disasterTypeFilter;
    const matchesSearch = shelter.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         shelter.address.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <div className="shelter-container">
      {/* Information Modal */}
      {showInfoModal && (
        <div className="info-modal">
          <div className="modal-content">
            <h3>🏠 Shelter Locator Information</h3>
            <p>
              This tool helps you find the nearest emergency shelters during disasters. 
              Shelters provide temporary housing, food, and medical assistance.
            </p>
            <ul>
              <li>🔹 <strong>List View</strong>: Shows detailed shelter information</li>
              <li>🔹 <strong>Map View</strong>: Visualizes shelter locations</li>
              <li>🔹 <strong>Filters</strong>: Find shelters specific to your disaster type</li>
              <li>🔹 <strong>Directions</strong>: Get navigation to selected shelters</li>
            </ul>
            <button 
              className="close-modal-btn"
              onClick={() => setShowInfoModal(false)}
            >
              Got It!
            </button>
          </div>
        </div>
      )}

      <h2>🏠 Nearest Emergency Shelters</h2>
      
      {/* Search and Filter Controls */}
      <div className="shelter-controls">
        <input
          type="text"
          placeholder="Search shelters..."
          className="search-input"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        
        <select
          className="type-filter"
          value={disasterTypeFilter}
          onChange={(e) => setDisasterTypeFilter(e.target.value)}
        >
          <option value="all">All Disaster Types</option>
          <option value="general">General Shelters</option>
          <option value="flood">Flood Shelters</option>
          <option value="earthquake">Earthquake Shelters</option>
          <option value="fire">Fire Shelters</option>
        </select>
        
        <button 
          className="map-toggle-btn"
          onClick={() => setShowMap(!showMap)}
        >
          {showMap ? 'Show List View' : 'Show Map View'}
        </button>
      </div>

      {showMap ? (
        <div className="map-placeholder">
          <h3>Shelter Map View</h3>
          <p>Map would display here with pins at these locations:</p>
          <ul>
            {filteredShelters.map(shelter => (
              <li key={shelter.id}>
                📍 {shelter.name} - {shelter.address}
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <div className="shelter-list">
          {filteredShelters.length > 0 ? (
            filteredShelters.map(shelter => (
              <div key={shelter.id} className="shelter-card">
                <h3>{shelter.name}</h3>
                <p>📍 Address: {shelter.address}</p>
                <p>🚶‍♂️ Distance: {shelter.distance} away</p>
                <p>👥 Capacity: {shelter.capacity}</p>
                <p>📞 Contact: {shelter.contact}</p>
                <p>⚠️ For: {shelter.type === 'general' ? 'All disasters' : `${shelter.type} emergencies`}</p>
                <div className="shelter-card-actions">
                  <button className="directions-btn">Get Directions</button>
                  <button className="details-btn">More Details</button>
                </div>
              </div>
            ))
          ) : (
            <p className="no-results">No shelters found matching your criteria.</p>
          )}
        </div>
      )}

      <div className="shelter-actions">
        <button 
          className="refresh-btn"
          onClick={() => {
            // In a real app, this would refresh data from API
            alert('Refreshing shelter data...');
          }}
        >
          ↻ Refresh Locations
        </button>
        <button 
          className="add-shelter-btn"
          onClick={() => {
            // Would open a form in a real app
            alert('Opening shelter reporting form...');
          }}
        >
          ➕ Report New Shelter
        </button>
        <button 
          className="info-btn"
          onClick={() => setShowInfoModal(true)}
        >
          ℹ️ Show Help
        </button>
      </div>
    </div>
  );
};

export default ShelterLocator;