import React, { useState, useEffect } from 'react';
import './SafetyTips.css';

const SafetyTips = () => {
  const [activeCategory, setActiveCategory] = useState('general');
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const tipsData = {
    general: [
      { id: 1, tip: "Always have an emergency kit ready with essentials", priority: "high" },
      { id: 2, tip: "Identify safe spots in your home for each type of disaster", priority: "medium" },
      { id: 3, tip: "Create and practice a family emergency plan", priority: "high" },
      { id: 4, tip: "Learn basic first aid and CPR", priority: "high" }
    ],
    flood: [
      { id: 1, tip: "Move to higher ground immediately", priority: "critical" },
      { id: 2, tip: "Avoid walking or driving through flood waters", priority: "critical" },
      { id: 3, tip: "Turn off electricity at the main breaker", priority: "high" },
      { id: 4, tip: "Store important documents in waterproof containers", priority: "medium" }
    ],
    earthquake: [
      { id: 1, tip: "Drop, Cover, and Hold On during shaking", priority: "critical" },
      { id: 2, tip: "Stay indoors until shaking stops", priority: "high" },
      { id: 3, tip: "Stay away from windows and heavy objects", priority: "high" },
      { id: 4, tip: "If outdoors, move to an open area away from buildings", priority: "high" }
    ],
    fire: [
      { id: 1, tip: "Check smoke alarms regularly", priority: "high" },
      { id: 2, tip: "Have an escape plan with two ways out", priority: "high" },
      { id: 3, tip: "Stop, Drop, and Roll if clothes catch fire", priority: "critical" },
      { id: 4, tip: "Never use elevators during a fire", priority: "high" }
    ]
  };

  // Show info modal when component first loads
  useEffect(() => {
    setShowInfoModal(true);
  }, []);

  const filteredTips = tipsData[activeCategory].filter(tip => 
    tip.tip.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="safety-tips-container">
      {/* Information Modal */}
      {showInfoModal && (
        <div className="info-modal">
          <div className="modal-content">
            <h3>🛡️ Safety Tips Guide</h3>
            <p>
              This section provides life-saving information for various emergency situations.
              Select a disaster type to view specific safety recommendations.
            </p>
            <ul>
              <li>🔹 <strong>Color Codes</strong>: Red = Critical, Orange = High, Yellow = Medium priority</li>
              <li>🔹 <strong>Search</strong>: Find specific tips quickly</li>
              <li>🔹 <strong>Print</strong>: Save tips for offline reference</li>
            </ul>
            <button 
              className="close-modal-btn"
              onClick={() => setShowInfoModal(false)}
            >
              Got It!
            </button>
          </div>
        </div>
      )}

      <h2>🛡️ Emergency Safety Tips</h2>
      
      {/* Search and Category Controls */}
      <div className="safety-controls">
        <input
          type="text"
          placeholder="Search tips..."
          className="search-input"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        
        <div className="category-tabs">
          <button 
            className={activeCategory === 'general' ? 'active' : ''}
            onClick={() => setActiveCategory('general')}
          >
            General
          </button>
          <button 
            className={activeCategory === 'flood' ? 'active' : ''}
            onClick={() => setActiveCategory('flood')}
          >
            Flood
          </button>
          <button 
            className={activeCategory === 'earthquake' ? 'active' : ''}
            onClick={() => setActiveCategory('earthquake')}
          >
            Earthquake
          </button>
          <button 
            className={activeCategory === 'fire' ? 'active' : ''}
            onClick={() => setActiveCategory('fire')}
          >
            Fire
          </button>
        </div>
      </div>
      
      <div className="tips-content">
        <h3>{activeCategory.charAt(0).toUpperCase() + activeCategory.slice(1)} Safety Guidelines</h3>
        
        {filteredTips.length > 0 ? (
          <ul className="tips-list">
            {filteredTips.map(tip => (
              <li 
                key={tip.id}
                className={`tip-item priority-${tip.priority}`}
              >
                <span className="tip-bullet">•</span>
                {tip.tip}
                {tip.priority === 'critical' && <span className="urgent-tag">URGENT</span>}
              </li>
            ))}
          </ul>
        ) : (
          <p className="no-results">No safety tips found matching your search.</p>
        )}
      </div>
      
      <div className="emergency-info">
        <div className="emergency-numbers">
          <h4>🚨 Emergency Contacts:</h4>
          <p>Police: 100 | Ambulance: 102 | Fire: 101 | Disaster Helpline: 108</p>
        </div>
        
        <div className="safety-actions">
          <button className="print-btn" onClick={() => window.print()}>
            🖨️ Print These Tips
          </button>
          <button 
            className="info-btn"
            onClick={() => setShowInfoModal(true)}
          >
            ℹ️ Show Help
          </button>
        </div>
      </div>
    </div>
  );
};

export default SafetyTips;