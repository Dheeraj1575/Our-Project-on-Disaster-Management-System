import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './TrackRelief.css';

function TrackRelief() {
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchResources = async () => {
      try {
        // Try to fetch from your API first
        const response = await axios.get('http://localhost:8080/api/resources');
        setResources(response.data);
      } catch (apiError) {
        console.warn('API not available, using mock data:', apiError);
        // Fallback to mock data if API fails
        setResources([
          {
            id: 1,
            name: 'Emergency Food Pack',
            type: 'Food',
            quantity: 250,
            location: 'Central Warehouse',
            status: 'In Stock',
            lastUpdated: '2023-06-15'
          },
          {
            id: 2,
            name: 'Medical Kits',
            type: 'Medical Supplies',
            quantity: 120,
            location: 'North District',
            status: 'Low Stock',
            lastUpdated: '2023-06-14'
          },
          {
            id: 3,
            name: 'Blankets',
            type: 'Shelter',
            quantity: 500,
            location: 'South Relief Center',
            status: 'In Stock',
            lastUpdated: '2023-06-16'
          },
          {
            id: 4,
            name: 'Water Purification Tablets',
            type: 'Water',
            quantity: 80,
            location: 'East Camp',
            status: 'Critical',
            lastUpdated: '2023-06-16'
          }
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchResources();
  }, []);

  if (loading) {
    return (
      <div className="track-relief-container">
        <div className="loading-spinner"></div>
        <p>Loading relief resources...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="track-relief-container">
        <div className="error-message">
          ⚠️ Error loading resources: {error.message}
        </div>
        <button onClick={() => window.location.reload()}>Retry</button>
      </div>
    );
  }

  return (
    <div className="track-relief-container">
      <h1>Relief Resource Tracking</h1>
      <p className="last-updated">Last updated: {new Date().toLocaleString()}</p>
      
      {resources.length === 0 ? (
        <div className="no-resources">
          <p>No relief resources currently available.</p>
          <button onClick={() => window.location.reload()}>Check Again</button>
        </div>
      ) : (
        <div className="resources-grid">
          {resources.map((resource) => (
            <div key={resource.id} className={`resource-card status-${resource.status?.toLowerCase().replace(' ', '-')}`}>
              <h3>{resource.name}</h3>
              <div className="resource-details">
                <p><strong>Type:</strong> {resource.type}</p>
                <p><strong>Quantity:</strong> <span className="quantity">{resource.quantity}</span></p>
                <p><strong>Location:</strong> {resource.location}</p>
                <p><strong>Status:</strong> <span className="status-badge">{resource.status || 'Unknown'}</span></p>
                {resource.lastUpdated && (
                  <p className="update-time">
                    <small>Updated: {new Date(resource.lastUpdated).toLocaleDateString()}</small>
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default TrackRelief;