import React, { useState, useEffect } from 'react';
import './LocationDisplay.css';

function LocationDisplay() {
  const [location, setLocation] = useState(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const getLocation = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setLocation({
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              accuracy: position.coords.accuracy,
              timestamp: new Date(position.timestamp)
            });
            setIsLoading(false);
          },
          (err) => {
            setError(getErrorText(err));
            setIsLoading(false);
          },
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
          }
        );
      } else {
        setError("Geolocation is not supported by this browser.");
        setIsLoading(false);
      }
    };

    // Request location when component mounts
    getLocation();
  }, []);

  const getErrorText = (error) => {
    switch(error.code) {
      case error.PERMISSION_DENIED:
        return "Location access was denied. Please enable location permissions.";
      case error.POSITION_UNAVAILABLE:
        return "Location information is unavailable.";
      case error.TIMEOUT:
        return "The request to get location timed out.";
      default:
        return "An unknown error occurred while getting location.";
    }
  };

  const refreshLocation = () => {
    setIsLoading(true);
    setError(null);
    setLocation(null);
    useEffect(() => getLocation(), []);
  };

  return (
    <div className="location-container">
      <h1>Emergency Location Sharing</h1>
      <p>Your current location will be displayed below:</p>
      
      {isLoading && (
        <div className="loading-state">
          <div className="spinner"></div>
          <p>Detecting your location...</p>
        </div>
      )}

      {error && (
        <div className="error-state">
          <p>{error}</p>
          <button onClick={refreshLocation} className="retry-btn">
            Try Again
          </button>
        </div>
      )}

      {location && (
        <div className="location-info">
          <h2>Your Current Location</h2>
          <div className="coordinates">
            <p><strong>Latitude:</strong> {location.latitude.toFixed(6)}</p>
            <p><strong>Longitude:</strong> {location.longitude.toFixed(6)}</p>
            <p><strong>Accuracy:</strong> ±{Math.round(location.accuracy)} meters</p>
            <p><strong>Last Updated:</strong> {location.timestamp.toLocaleTimeString()}</p>
          </div>
          
          <div className="map-link">
            <a
              href={`https://www.google.com/maps?q=${location.latitude},${location.longitude}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              View on Google Maps
            </a>
          </div>
        </div>
      )}
    </div>
  );
}

export default LocationDisplay;