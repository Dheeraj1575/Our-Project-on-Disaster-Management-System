import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Navigation.css';

function Navigation() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in
    const token = localStorage.getItem('authToken');
    setIsLoggedIn(!!token);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
    setIsLoggedIn(false);
    navigate('/');
  };

  return (
    <nav className="nav">
      <h2>Disaster Management</h2>
      <div className="nav-links">
        <Link to="/">Home</Link>
        <Link to="Location">DisasterManagement</Link>
        <Link to="/report">Report Incident</Link>
        <Link to="/track">Track Relief</Link>
        <Link to="/resources">Resource Allocation</Link>
        <Link to="/shelter-locator">Find Shelters</Link>
        <Link to="/safety-tips">Safety Tips</Link>
        <Link to="/login">Login</Link>
        <Link to="/signup">Sign Up</Link>
      </div>
    </nav>
  );
}

export default Navigation;