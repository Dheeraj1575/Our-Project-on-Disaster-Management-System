import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import DisasterManagement from './components/LocationDisplay';
import Home from './pages/Home';
import ReportIncident from './pages/ReportIncident';
import TrackRelief from './pages/TrackRelief';
import ResourceAllocation from './pages/ResourceAllocation';
import ShelterLocator from './pages/ShelterLocator';
import SafetyTips from './pages/SafetyTips';
import Login from './pages/Login';

import './App.css';

function App() {
  return (
    <Router>
      <Navigation />
      <DisasterManagement />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/report" element={<ReportIncident />} />
        <Route path="/track" element={<TrackRelief />} />
        <Route path="/resources" element={<ResourceAllocation />} />
        <Route path="/shelter-locator" element={<ShelterLocator />} />
        <Route path="/safety-tips" element={<SafetyTips />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </Router>
  );
}

export default App;